var camera, scene, renderer, controls;
var objects = [];
var tiros = [];
var inimigos = [];
var collmeshList = [];
var raycaster;
var blocker = document.getElementById( 'blocker' );
var instructions = document.getElementById( 'instructions' );
// http://www.html5rocks.com/en/tutorials/pointerlock/intro/
var havePointerLock = 'pointerLockElement' in document || 'mozPointerLockElement' in document || 'webkitPointerLockElement' in document;
if ( havePointerLock ) {
	var element = document.body;
	var pointerlockchange = function ( event ) {
		if ( document.pointerLockElement === element || document.mozPointerLockElement === element || document.webkitPointerLockElement === element ) {
			controlsEnabled = true;
			controls.enabled = true;
			blocker.style.display = 'none';
		} else {
			controls.enabled = false;
			blocker.style.display = 'block';
			instructions.style.display = '';
		}
	};
	var pointerlockerror = function ( event ) {
		instructions.style.display = '';
	};
	// Hook pointer lock state change events
	document.addEventListener( 'pointerlockchange', pointerlockchange, false );
	document.addEventListener( 'mozpointerlockchange', pointerlockchange, false );
	document.addEventListener( 'webkitpointerlockchange', pointerlockchange, false );
	document.addEventListener( 'pointerlockerror', pointerlockerror, false );
	document.addEventListener( 'mozpointerlockerror', pointerlockerror, false );
	document.addEventListener( 'webkitpointerlockerror', pointerlockerror, false );
	instructions.addEventListener( 'click', function ( event ) {
		instructions.style.display = 'none';
		// Ask the browser to lock the pointer
		element.requestPointerLock = element.requestPointerLock || element.mozRequestPointerLock || element.webkitRequestPointerLock;
		element.requestPointerLock();
	}, false );
} else {
	instructions.innerHTML = 'Your browser doesn\'t seem to support Pointer Lock API';
}
var controlsEnabled = false;
var moveForward = false;
var moveBackward = false;
var moveLeft = false;
var moveRight = false;
var canJump = false;
var prevTime = performance.now();
var velocity = new THREE.Vector3();
var direction = new THREE.Vector3();
var vertex = new THREE.Vector3();
var color = new THREE.Color();
init();
animate();
function init() {
	camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 1, 1000 );
	scene = new THREE.Scene();
	scene.background = new THREE.Color( 0xffffff );
	scene.fog = new THREE.Fog( 0xffffff, 0, 1000 );
	var light = new THREE.HemisphereLight( 0xeeeeff, 0x777788, 0.75 );
	light.position.set( 0.5, 1, 0.75 );
	scene.add( light );
	controls = new THREE.PointerLockControls( camera );
	scene.add( controls.getObject() );
	var onKeyDown = function ( event ) {
		switch ( event.keyCode ) {
			case 38: // up
			case 87: // w
				moveForward = true;
				break;
			case 37: // left
			case 65: // a
				moveLeft = true; break;
			case 40: // down
			case 83: // s
				moveBackward = true;
				break;
			case 39: // right
			case 68: // d
				moveRight = true;
				break;
			/*
			case 32: // space
				if ( canJump === true ) velocity.y += 350;
				canJump = false;
				break;
			*/
		}
	};
	var onKeyUp = function ( event ) {
		switch( event.keyCode ) {
			case 38: // up
			case 87: // w
				moveForward = false;
				break;
			case 37: // left
			case 65: // a
				moveLeft = false;
				break;
			case 40: // down
			case 83: // s
				moveBackward = false;
				break;
			case 39: // right
			case 68: // d
				moveRight = false;
				break;
		}
	};
	document.addEventListener( 'keydown', onKeyDown, false );
	document.addEventListener( 'keyup', onKeyUp, false );
	raycaster = new THREE.Raycaster( new THREE.Vector3(), new THREE.Vector3( 0, - 1, 0 ), 0, 10 );




	//--------------------TIRO-----------------------TIRO----------------------------
	function tiro(){
		var tiro = new THREE.Mesh(
			new THREE.SphereGeometry(0.5,5,5)
		);
		tiro.position.x = controls.getObject().position.x;
		tiro.position.y = controls.getObject().position.y -1;
		tiro.position.z = controls.getObject().position.z;
		tiro.vel = controls.getObject();
		//tiro.ang = controls.getPitchObject();
		tiro.velocity = new THREE.Vector3(-Math.sin(tiro.vel.rotation.y),0,-Math.cos(tiro.vel.rotation.y));

		tiro.vivo = true;
		/*
		setTimeout(function(){
			tiro.vivo = false;
			scene.remove(tiro);
		}, 1000)
		*/
		scene.add(tiro);
		tiros.push(tiro);

  }
	window.addEventListener("click", tiro);


//--------------------TIRO---------------------------TIRO------------------------


//	function inimigo(){
		var boxGeometry = new THREE.BoxBufferGeometry( 20, 20, 20 );
		boxGeometry = boxGeometry.toNonIndexed(); // ensure each face has unique vertices
		count = boxGeometry.attributes.position.count;
		colors = [];
		for ( var i = 0; i < count; i ++ ) {
			color.setHSL( Math.random() * 0.3 + 0.5, 0.75, Math.random() * 0.25 + 0.75 );
			colors.push( color.r, color.g, color.b );
		}
		boxGeometry.addAttribute( 'color', new THREE.Float32BufferAttribute( colors, 3 ) );
		for ( var i = 0; i < 50; i ++ ) {
			//var boxMaterial = new THREE.MeshPhongMaterial( { specular: 0xffffff, flatShading: true, vertexColors: THREE.VertexColors } );
			//boxMaterial.color.setHSL( Math.random() * 0.2 + 0.5, 0.75, Math.random() * 0.25 + 0.75 );
			var box = new THREE.Mesh( boxGeometry );
			//box.vivo = true;
			if (i>15 && i<25) {
				box.position.x = Math.floor( Math.random() * 500 - 20 );
				box.position.y = 10;
				box.position.z = Math.floor( Math.random() * 500 - 20 );
			}
			if(i>=25 && i<35) {
				box.position.x = Math.floor( Math.random() * -500 + 20 );
				box.position.y = 10;
				box.position.z = Math.floor( Math.random() * 500 - 20 );
			}
			if(i>=35 && i<42) {
				box.position.x = Math.floor( Math.random() * 500 - 20 );
				box.position.y = 10;
				box.position.z = Math.floor( Math.random() * -500 + 20 );
			}
			if( i>42) {
				box.position.x = Math.floor( Math.random() * -500 + 20 );
				box.position.y = 10;
				box.position.z = Math.floor( Math.random() * -500 + 20 );
			}
			scene.add( box );
			inimigos.push( box );
		}
	//}




	//-----------------ImportModels--------------------------------
		// texture

		var manager = new THREE.LoadingManager();
		manager.onProgress = function ( item, loaded, total ) {

			console.log( item, loaded, total );

		};

		//var textureLoader = new THREE.TextureLoader( manager );
		//var texture = textureLoader.load( 'textures/UV_Grid_Sm.jpg' );

		// model

		var onProgress = function ( xhr ) {
			if ( xhr.lengthComputable ) {
				var percentComplete = xhr.loaded / xhr.total * 100;
				console.log( Math.round(percentComplete, 2) + '% downloaded' );
			}
		};
		var onError = function ( xhr ) {
		};
		var loader = new THREE.OBJLoader( manager );
		loader.load( 'js/obj/Tommy.obj', function ( object ) {
			object.traverse( function ( child ) {
				if ( child instanceof THREE.Mesh ) {
					//child.material.map = texture;
				}
			} );
			object.position.y = -3;
			object.position.x = -3;
			object.position.z = -5;
			object.rotateY( - Math.PI );
			scene.add( object );
			camera.add(object);
		}, onProgress, onError );
		var manager = new THREE.LoadingManager();
		manager.onProgress = function ( item, loaded, total ) {
			console.log( item, loaded, total );
		};

		//var textureLoader = new THREE.TextureLoader( manager );
		//var texture = textureLoader.load( 'textures/UV_Grid_Sm.jpg' );

		// model

		var onProgress = function ( xhr ) {
			if ( xhr.lengthComputable ) {
				var percentComplete = xhr.loaded / xhr.total * 100;
				console.log( Math.round(percentComplete, 2) + '% downloaded' );
			}
		};
		var onError = function ( xhr ) {
		};
		var loader = new THREE.OBJLoader( manager );
		loader.load( 'js/obj/Tommy.obj', function ( object ) {

			object.traverse( function ( child ) {

				if ( child instanceof THREE.Mesh ) {
					//child.material.map = texture;
				}
			} );
			object.position.y = -3;
			object.position.x = 3;
			object.position.z = -5;
			object.rotateY( - Math.PI );
			scene.add( object );
			camera.add(object);
			//camera.add(object);
		}, onProgress, onError );




	//-----------------ImportModels--------------------------------




	// floor
	var floorGeometry = new THREE.PlaneBufferGeometry( 2000, 2000, 100, 100 );
	floorGeometry.rotateX( - Math.PI / 2 );
	// vertex displacement
	var position = floorGeometry.attributes.position;
	for ( var i = 0; i < position.count; i ++ ) {
		vertex.fromBufferAttribute( position, i );
		vertex.x += Math.random() * 20 - 10;
		vertex.y += Math.random() * 2;
		vertex.z += Math.random() * 20 - 10;
		position.setXYZ( i, vertex.x, vertex.y, vertex.z );
	}
	floorGeometry = floorGeometry.toNonIndexed(); // ensure each face has unique vertices
	count = floorGeometry.attributes.position.count;
	var colors = [];
	for ( var i = 0; i < count; i ++ ) {
		color.setHSL(  0.5, 0.75,  0.75 );
		colors.push( color.r, color.g, color.b );
	}
	floorGeometry.addAttribute( 'color', new THREE.Float32BufferAttribute( colors, 3 ) );
	var floorMaterial = new THREE.MeshBasicMaterial( { vertexColors: THREE.VertexColors } );
	var floor = new THREE.Mesh( floorGeometry, floorMaterial );
	scene.add( floor );


	// objects
	/*
	var boxGeometry = new THREE.BoxBufferGeometry( 20, 20, 20 );
	boxGeometry = boxGeometry.toNonIndexed(); // ensure each face has unique vertices
	count = boxGeometry.attributes.position.count;
	colors = [];
	for ( var i = 0; i < count; i ++ ) {
		color.setHSL( Math.random() * 0.3 + 0.5, 0.75, Math.random() * 0.25 + 0.75 );
		colors.push( color.r, color.g, color.b );
	}
	boxGeometry.addAttribute( 'color', new THREE.Float32BufferAttribute( colors, 3 ) );
	for ( var i = 0; i < 500; i ++ ) {
		var boxMaterial = new THREE.MeshPhongMaterial( { specular: 0xffffff, flatShading: true, vertexColors: THREE.VertexColors } );
		boxMaterial.color.setHSL( Math.random() * 0.2 + 0.5, 0.75, Math.random() * 0.25 + 0.75 );
		var box = new THREE.Mesh( boxGeometry, boxMaterial );
		box.position.x = Math.floor( Math.random() * 20 - 10 ) * 20;
		box.position.y = Math.floor( Math.random() * 20 ) * 20 + 10;
		box.position.z = Math.floor( Math.random() * 20 - 10 ) * 20;
		scene.add( box );
		objects.push( box );
	}
	*/


	//walls
	var sideWallsGeometry = new THREE.BoxBufferGeometry(2050, 40, 40);
	var sideWallsMaterial = new THREE.MeshPhongMaterial( { specular: 0xffffff, flatShading: true, vertexColors: THREE.VertexColors } );
	sideWallsMaterial.color.setHSL( 0.5, 0.75, 0.75 );

	for (var i = 0; i < 4; i++) {
		var sideWalls = new THREE.Mesh( sideWallsGeometry, sideWallsMaterial );
		sideWalls.position.x =  0;
		sideWalls.position.y =  20;
		if(i == 0){
			sideWalls.position.z =  1000;
			scene.add( sideWalls );
			objects.push( sideWalls );
			collmeshList.push(sideWalls);
		}
		if(i == 1){
			sideWalls.position.z =  -1000;
			scene.add( sideWalls );
			objects.push( sideWalls );
			collmeshList.push(sideWalls);
		}
		if(i == 2){
			var sideWallsGeometry = new THREE.BoxBufferGeometry(40, 40, 2050);
			var sideWalls = new THREE.Mesh( sideWallsGeometry, sideWallsMaterial );
			sideWalls.position.x =  1000;
			sideWalls.position.y =  20;
			sideWalls.position.z =  0;
			scene.add( sideWalls );
			objects.push( sideWalls );
			collmeshList.push(sideWalls);
		}
		if(i == 3){
			sideWalls.position.x =  -1000;
			sideWalls.position.z =  0;
			scene.add( sideWalls );
			objects.push( sideWalls );
			collmeshList.push(sideWalls);
		}
	}

	//
	renderer = new THREE.WebGLRenderer( { antialias: true } );
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
	document.body.appendChild( renderer.domElement );
	//
	window.addEventListener( 'resize', onWindowResize, false );


}



function onWindowResize() {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize( window.innerWidth, window.innerHeight );
}
function animate() {
	requestAnimationFrame( animate );

	for (var index= 0; index < tiros.length; index++) {
		if (tiros[index]===undefined)continue;
		if(tiros[index].vivo == false){
			tiros.splice(index, 1);
			continue;
		}
		tiros[index].position.add(tiros[index].velocity);
		tiros[index].position.add(tiros[index].velocity);
		tiros[index].position.add(tiros[index].velocity);
		if(tiros[index].position.x > 980 || tiros[index].position.x < -980)
			tiros[index].vivo = false;
		if(tiros[index].position.z > 980 || tiros[index].position.z < -980)
			tiros[index].vivo = false;

		for (var ind= 0; ind < inimigos.length; ind++) {
			if (inimigos[ind]===undefined)continue;
			if(tiros[index].vivo == false){
				tiros.splice(index, 1);
				continue;
			}
			//if(inimigos[index].vivo == false){
			//	inimigos.splice(index, 1);
			//	continue;
			//}
			if (tiros[index].position.x <= inimigos[ind].position.x-10 && tiros[index].position.x >= inimigos[ind].position.x+10){
				tiros[index].vivo = false;
				scene.remove(inimigos[ind]);
			}
			if (tiros[index].position.z <= inimigos[ind].position.z-10 && tiros[index].position.z >= inimigos[ind].position.z+10){
				tiros[index].vivo = false;
				scene.remove(inimigos[ind]);
			}
		}

		if(tiros[index].vivo == false)
			scene.remove(tiros[index]);

	}

	for (var index= 0; index < inimigos.length; index++) {
		if (inimigos[index]===undefined)continue;
		//if(inimigos[index].vivo == false){
		//	inimigos.splice(index, 1);
		//	continue;
		//}
		if (inimigos[index].position.x > controls.getObject().position.x)
			inimigos[index].position.x-= 0.25;
		if (inimigos[index].position.x < controls.getObject().position.x)
			inimigos[index].position.x+= 0.25;
		if (inimigos[index].position.z > controls.getObject().position.z)
			inimigos[index].position.z-= 0.25;
		if (inimigos[index].position.z < controls.getObject().position.z)
			inimigos[index].position.z+= 0.25;
		//if(tiros[index].vivo == false)
		//	scene.remove(tiro);
	}



	if ( controlsEnabled === true ) {
		raycaster.ray.origin.copy( controls.getObject().position );
		raycaster.ray.origin.y -= 10;
		var intersections = raycaster.intersectObjects( objects );
		var onObject = intersections.length > 0;
		var time = performance.now();
		var delta = ( time - prevTime ) / 1000;
		//velocity.x -= velocity.x * 1.0 * delta; //velocidade
		//velocity.z -= velocity.z * 1.0 * delta; //velocidade

		velocity.x = 1.5;
		velocity.z = 1.5;

		velocity.y -= 9.8 * 100.0 * delta; // 100.0 = mass
		direction.z = Number( moveForward ) - Number( moveBackward );
		direction.x = Number( moveLeft ) - Number( moveRight );
		direction.normalize(); // this ensures consistent movements in all directions
		//if ( moveForward || moveBackward ) velocity.z -= direction.z * 400.0 * delta;
		//if ( moveLeft || moveRight ) velocity.x -= direction.x * 400.0 * delta;

		//movimentacao nova
		if ( moveForward) velocity.z = -velocity.z;
		if( moveBackward ) velocity.z = velocity.z;
		if ( moveLeft ) velocity.x = -velocity.x;
		if ( moveRight ) velocity.x = velocity.x;
		if(moveForward == false && moveBackward == false) velocity.z = 0;
		if(moveLeft == false && moveRight == false) velocity.x = 0;


		if ( onObject === true ) {
			velocity.y = Math.max( 0, velocity.y );
			canJump = true;
		}


		collisionDetection(controls, collmeshList);

		if(moveForward == false && moveBackward == false) velocity.z = 0;
		if(moveLeft == false && moveRight == false) velocity.x = 0;
		//controls.getObject().translateX( velocity.x * delta );
		controls.getObject().translateX( velocity.x );
		//controls.getObject().translateY( velocity.y * delta );
		controls.getObject().translateY( velocity.y );
		//controls.getObject().translateZ( velocity.z * delta );
		controls.getObject().translateZ( velocity.z );






		if ( controls.getObject().position.y < 10 ) {//controle de pulo
			velocity.y = 0;
			controls.getObject().position.y = 10;
			canJump = true;
		}


		prevTime = time;
	}
	renderer.render( scene, camera );
}

var collisionDetection = function(controls, collmeshList) {

    function bounceBack(position, ray) {
        position.x -= ray.bounceDistance.x;
        position.y -= ray.bounceDistance.y;
        position.z -= ray.bounceDistance.z;
    }

    var rays = [
        //   Time    Degrees      words
        new THREE.Vector3(0, 0, 5),  // 0 12:00,   0 degrees,  deep
        new THREE.Vector3(5, 0, 5),  // 1  1:30,  45 degrees,  right deep
        new THREE.Vector3(5, 0, 0),  // 2  3:00,  90 degress,  right
        new THREE.Vector3(5, 0, -5), // 3  4:30, 135 degrees,  right near
        new THREE.Vector3(0, 0, -5), // 4  6:00  180 degress,  near
        new THREE.Vector3(-5, 0, -5),// 5  7:30  225 degrees,  left near
        new THREE.Vector3(-5, 0, 0), // 6  9:00  270 degrees,  left
        new THREE.Vector3(-5, 0, 5)  // 7 11:30  315 degrees,  left deep
    ];

    var position = controls.getObject().position;
    var rayHits = [];
    for (var index = 0; index < rays.length; index += 1) {

        // Set bounce distance for each vector
        var bounceSize = 1;
        rays[index].bounceDistance = {
            x: rays[index].x * bounceSize,
            y: rays[index].y * bounceSize,
            z: rays[index].z * bounceSize
        };

        raycaster.set(position, rays[index]);

        var intersections = raycaster.intersectObjects(collmeshList);

        if (intersections.length > 0 && intersections[0].distance <= 10) {
			console.log(intersections[0].distance);
            controls.isOnObject = true;
            bounceBack(position, rays[index]);
        }
    }

    return false;
};
